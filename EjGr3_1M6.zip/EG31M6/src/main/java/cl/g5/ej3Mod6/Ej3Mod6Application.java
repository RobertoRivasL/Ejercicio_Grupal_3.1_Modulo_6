package cl.g5.ej3Mod6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej3Mod6Application {

    public static void main(String[] args) {
        SpringApplication.run(Ej3Mod6Application.class, args);
    }

}
